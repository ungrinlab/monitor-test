<?
	include '/var/www/header.php';
	$config_file="sensor_config.php";
	echo "<BODY>";
	echo "<FORM NAME=sensor_config action=update_sensor_config.php method=POST>";

	$findsender="cat $config_file | grep 'InterfaceKit connected =' | perl -pe 's/InterfaceKit connected = //g'";
	exec($findsender, $interfacekit_connected);

	$findsender="cat $config_file | grep 'Thermocouple connected =' | perl -pe 's/Thermocouple connected = //g'";
	exec($findsender, $thermocouple_connected);

	echo "<TABLE>";
		echo "<TR><TD><h1>Kits connected</h1></TD></TR>";
		echo "<TD>Interface Kit connected</TD><TD><SELECT NAME=interfacekit_connected>";
		if ($interfacekit_connected[0] == "Y") {
			echo "<OPTION SELECTED>Y</OPTION>";
			echo "<OPTION>N</OPTION>";
		} else {
			echo "<OPTION>Y</OPTION>";
			echo "<OPTION SELECTED>N</OPTION>";
		}
		echo "</TR>";
		echo "<TR><TD>Thermocouple connected</TD><TD><SELECT NAME=thermocouple_connected>";
		if ($thermocouple_connected[0] == "Y") {
			echo "<OPTION SELECTED>Y</OPTION>";
			echo "<OPTION>N</OPTION>";
		} else {
			echo "<OPTION>Y</OPTION>";
			echo "<OPTION SELECTED>N</OPTION>";
		}
		echo "</TR>";
	echo "</TABLE>";
	echo "<TABLE>";
	echo "<TR><TD colspan=4><h1>Sensors connected on analog ports</h1></TD></TR>";
	for ($i=0; $i < 8; $i++) {
		$findname="cat $config_file | grep '#m_port".$i."_name' | perl -pe 's/#m_port".$i."_name = //g'";
		exec($findname, $port_name);

		$findtype="cat $config_file | grep '#m_port".$i."_type' | perl -pe 's/#m_port".$i."_type = //g'";
		exec($findtype, $port_type);

		$findupper="cat $config_file | grep 'upper limit M".$i."' | perl -pe 's/upper limit M".$i." = //g'";
		exec($findupper, $port_upper);

		$findlower="cat $config_file | grep 'lower limit M".$i."' | perl -pe 's/lower limit M".$i." = //g'";
		exec($findlower, $port_lower);

		$port_type_options[0] = "NONE";
		$port_type_options[1] = "temperature [1124]";
		$port_type_options[2] = "pressure [1115]";
		$port_type_options[3] = "pressure [1140]";
		$port_type_options[4] = "pressure [1141]";

		echo "<TR><TD>Port M".$i.":</TD><TD>sensor type:<SELECT NAME=m_port".$i."_type>";
		for ($j = 0; $j < count($port_type_options); $j++) {
			if ($port_type[$i] == $port_type_options[$j]) {
				echo "<OPTION SELECTED>".$port_type_options[$j]."</OPTION>";
			} else {
				echo "<OPTION>".$port_type_options[$j]."</OPTION>";
			}
		}
		echo "	</SELECT></TD>";
		echo "<TD>sensor label:<input TYPE=TEXT NAME=m_port".$i."_name VALUE='".$port_name[$i]."' SIZE=40></TD>";
		echo "<TD>minimum normal value:<input TYPE=NUMBER NAME=m_port".$i."_low VALUE='".$port_lower[$i]."'></TD>";
		echo "<TD>maximum normal value:<input TYPE=NUMBER NAME=m_port".$i."_high VALUE='".$port_upper[$i]."'></TD>";
		echo "</TR>";
	}
	echo "</TABLE>";

        echo "<HR>";

        echo "<TABLE>";
	echo "<TR><TD colspan=4><h1>Sensors connected on digital ports</h1></TD></TR>";
        for ($i=0; $i < 8; $i++) {
                $findname="cat $config_file | grep 'Port D".$i." = ' | perl -pe 's/Port D".$i." = //g'";
                exec($findname, $d_port_name);

                $findstatepref="cat $config_file | grep 'desired state D".$i." = ' | perl -pe 's/desired state D".$i." = //g'";
                exec($findstatepref, $d_port_state);

                $findstatetimeout="cat $config_file | grep 'state timeout D".$i." = ' | perl -pe 's/state timeout D".$i." = //g'";
                exec($findstatetimeout, $d_port_timeout);

		echo "<TR><TD>Port D".$i.":</TD>";
                echo "<TD>sensor label:<input TYPE=TEXT NAME=d_port".$i."_name VALUE='".$d_port_name[$i]."' SIZE=40></TD>";
		echo "<TD>Port ".$i.":</TD><TD>expected normal value<SELECT NAME=d_port".$i."_expected_state>";
		if ($d_port_state[$i] == "TRUE") {
			echo "<OPTION SELECTED>TRUE</OPTION>";
			echo "<OPTION>FALSE</OPTION>";
		} else {
			echo "<OPTION>TRUE</OPTION>";
			echo "<OPTION SELECTED>FALSE</OPTION>";
		}
                echo "<TD>abnormal reading is acceptable for <input TYPE=NUMBER NAME=d_port".$i."_timeout VALUE='".$d_port_timeout[$i]."'> minutes</TD>";
                echo "</TR>";
        }
        echo "</TABLE>";

        echo "<HR>";

        echo "<TABLE>";
	echo "<TR><TD colspan=4><h1>Sensors connected to thermocouple adapter</h1></TD></TR>";
        for ($i=0; $i < 4; $i++) {
                $findname="cat $config_file | grep 'Port T".$i." = ' | perl -pe 's/Port T".$i." = //g'";
                exec($findname, $t_port_name);

		$findupper="cat $config_file | grep 'upper limit T".$i."' | perl -pe 's/upper limit T".$i." = //g'";
		exec($findupper, $t_port_upper);

		$findlower="cat $config_file | grep 'lower limit T".$i."' | perl -pe 's/lower limit T".$i." = //g'";
		exec($findlower, $t_port_lower);

		echo "<TR><TD>Port T".$i.":</TD>";
                echo "<TD>sensor label:<input TYPE=TEXT NAME=t_port".$i."_name VALUE='".$t_port_name[$i]."' SIZE=40></TD>";
                echo "<TD>minimum normal value:<input TYPE=NUMBER NAME=t_port".$i."_low VALUE='".$t_port_lower[$i]."'></TD>";
                echo "<TD>maximum normal value:<input TYPE=NUMBER NAME=t_port".$i."_high VALUE='".$t_port_upper[$i]."'></TD>";
                echo "</TR>";

        }
        echo "</TABLE>";


	$findsender="cat $config_file | grep 'From Address =' | perl -pe 's/From Address = //g'";
	exec($findsender, $from_address);

	$findsender="cat $config_file | grep 'To Address =' | perl -pe 's/To Address = //g'";
	exec($findsender, $to_address);

	$findtimer="cat $config_file | grep 'Email Timer =' | perl -pe 's/Email Timer = //g'";
	exec($findtimer, $alert_timer);

	echo "<BR><h1>Notification settings</h1>";
	echo "<BR>Send alert emails from (must be a gmail account)<input type=email name=from_address value='".$from_address[0]."' SIZE=50>";
	echo "<BR>Email password:<input type=password name=email_password>";
	echo "<BR>Send alert emails to <input type=email name=to_address value='".$to_address[0]."' SIZE=50>";
	echo "<BR>Wait <input type=number name=repeat_alert value='".$alert_timer[0]."'> minutes between successive email alerts.";
	echo "<input type=hidden name=from_config_form value=yes>";

        echo "<p>Login for sensor configuration: <input type='text' value='$username' size=50 name='username'></p>";
        echo "<p>New password for sensor configuration: <input type='password' value='$password' size=50 name='password'></p>";
        echo "<p><input type='submit' value='Update settings'></P>";


        echo "</TABLE>";
	echo "</FORM>";
	echo "</BODY>";
?>
