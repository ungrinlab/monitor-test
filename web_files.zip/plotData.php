<?php

$plotTitle=$_GET["plotTitle"];
$height=$_GET["height"];
$width=$_GET["width"];
$skipData = $_GET["skip"];
$numDataPoints = $_GET["numX"];
$showSeries = explode(",",$_GET["series"]);
if ($height < 200) $height=800;
if ($width < 300) $width=1000;
if ($skipData < 1) $skipData=1;
if ($numDataPoints < 1) $numDataPoints=100;
if ($showSeries == NULL) $showSeries = "ALL";


 /* CAT:Plot chart */

 /* pChart library inclusions */
include("pChart/class/pData.class.php");
include("pChart/class/pDraw.class.php");
include("pChart/class/pImage.class.php");
include("pChart/class/pScatter.class.php");

//$tmp=exec("awk '!(NR%".$skipData.")' sensor_logs.txt | tail -n 100 > tempdat.txt");
if ($skipData > 1) {
//	$tmp = "awk '!(NR%".$skipData.")' monitor_log_akshay.txt | tail -n ".$numDataPoints." > tempdat.txt";
	$tmp = "cat monitor_log.txt | tail -n ".($skipData*$numDataPoints+1)." | awk '!(NR%".$skipData.")' | tail -n ".$numDataPoints." > tempdat.txt";
//	$tmp = "awk '!(NR%".$skipData.")' sensor_logs.txt | tail -n 100 > tempdat.txt";
} else {
	$tmp = "cat monitor_log.txt | tail -n ".$numDataPoints." > tempdat.txt";
}

exec($tmp);
//$tmp=exec("awk '!(NR%10)' sensor_logs.txt | tail -n 100 > tempdat.txt");

function processDataLine($line)
{

	$values=explode("|",$line);
	$vc = count($values);
	if ($values[$vc-1] == "\n") unset($values[$vc-1]);

	$dateTime=$values[0];

	$XandYs["texttimestamp"] = $dateTime;
	$XandYs["timestamp"] = strtotime($dateTime);

	for ($i = 1; $i < count($values); $i++) {
		$portname = substr(strrchr($values[$i],"@"),1,2);
		$valstart = substr(strrchr($values[$i],"="),1);
		$vals=$values[$i];
		$tmp=strstr($valstart," ",TRUE);
		if ($tmp == FALSE) $tmp = $valstart;
		$portVal = $tmp;
		if ($portVal == "True") $portVal = 1;
		if ($portVal == "False") $portVal = 0;
        	$XandYs[$portname] = $portVal;
	}
	return $XandYs;
} // end of processDataLine

$startTime=time();
$file = fopen("tempdat.txt", "r");
$i=0;
if ($file) {
    $allKeys=array();
    while (($line = fgets($file)) !== false) {
        // process the line read.
	$dataTemp = processDataLine($line);
//	$theseKeys = array_keys($dataTemp); // pulls out all the keys (i.e. every sensor whose data appears in this data line)
//	$allKeys = array_merge($allKeys, $dataTemp); // since we are using arrays with named keys, this builds a one-dimensional array with one key-value pair for every key encountered (in case some sensors turn on and off in the data)
//	echo "HHHH";
//	print_r($theseKeys);

	foreach ($showSeries as $thisKey) {
		$data[$thisKey][$i] = $dataTemp[$thisKey];
//		echo "--->$thisKey<---";
	}

	$data[0][$i] = $dataTemp["timestamp"];
	$data[-1][$i] = $dataTemp["texttimestamp"];
	$i++;
    }
//	$uniqueKeys = array_keys(array_flip($allKeys)); // pulls out all the unique keys (i.e. every sensor whose data ever appears in the data read)
//	print_r($uniqueKeys);

} else {
    // error opening the file.
}
fclose($file);

if ($numDataPoints > count($data[0])) $numDataPoints = count($data[0]); // NB that not all series necessarily have the same number of datapoints as the time series



//echo "DONE<BR><BR><BR><BR><BR><BR><BR>";



//$date1 = date_create($data[0][0]);
$date1 = date('Y/m/d H:i:s', $data[0][0]);
$date2 = date('Y/m/d H:i:s', $data[0][$numDataPoints-1]);
//$date1="test";
$timespan = $data[0][$numDataPoints-1]-$data[0][0];
$avgInterval = $timespan / (($numDataPoints-1)*$skipData);

//$plotTitle = date_format($date1, 'Y-m-d H:i:sP')."->".count($data[0])." data points, reading every ".$skipData." from file";
//$plotTitle = $date1."->".count($data[0])." data points, reading every ".$skipData." from file, over ".$timespan." seconds (~".round($avgInterval,1)." second intervals)".data[0][0];
$plotTitle = count($data[0])." data points, reading every ".$skipData." from file, over ".$timespan." seconds (~".round($avgInterval,1)." second intervals), series: ".$showSeries;
$plotTitle2 = "From ".$date1." to ".$date2." (UTC - subtract 7 hours to get MST, or 6 hours to get MDT)";

//.(strtok(trim("")," ")<0)."<<<".strtok(trim("")," ")."<<<";

$values=explode(",",$line);
$num_sensors=(count($values)-1)/3;


/* Create the pData object */
$myData = new pData();



/* Create the X axis and the binded series */
$myData->setAxisName(0,"Date");
$myData->setAxisXY(0,AXIS_X);
$myData->setAxisPosition(0,AXIS_POSITION_BOTTOM);
$myData->setAxisDisplay(0,AXIS_FORMAT_DATE,"Y-m-d H:i");

/* Create the Y axis and the binded series */
$myData->setAxisName(1,"Values");
$myData->setAxisXY(1,AXIS_Y);
$myData->setAxisPosition(1,AXIS_POSITION_LEFT);

for ($j=0; $j < count($data[-1]); $j++) {
	$timePoints[$j]=strtotime($data[-1][$j]);
}

//$myData->addPoints($data[-1],"Labels");
$myData->addPoints($timePoints,"Labels");
$myData->setSerieOnAxis("Labels",0); // the time will be shown on the X axis


//for ($i=0;$i<=360;$i=$i+10) { $myData->addPoints(cos(deg2rad($i))*20,"Probe 1"); }
//for ($i=0;$i<=360;$i=$i+10) { $myData->addPoints(sin(deg2rad($i))*20,"Probe 2"); }


if ($showSeries == "ALL") {
	for ($j=1; $j < count($dataTemp)-1; $j++) { // this is bad because it counts only the last line - if earlier lines have more data series they will be ignored
		$myData->addPoints($data[$j],"Port ".($j-1));
		$myData->setSerieOnAxis("Port ".($j-1),1); // the data will be shown on the Y axis
		$myData->setScatterSerie("Labels","Port ".($j-1),($j-1));
		$myData->setScatterSerieDescription(($j-1),"Port ".($j-1));
	}
} else {
	$j=0;
	foreach ($showSeries as $thisSeries) {
		$myData->addPoints($data[$thisSeries],"Port ".$thisSeries);
		$myData->setSerieOnAxis("Port ".$thisSeries,1); // the data will be shown on the Y axis
		$myData->setScatterSerie("Labels","Port ".$thisSeries,$j);
		$myData->setScatterSerieDescription($j,"Port ".$thisSeries);
		//$myData->setScatterSerieColor(0,array("R"=>255,"G"=>0,"B"=>0));
		$j++;
	}
}


 /* Create the pChart object */
 $myPicture = new pImage($width,$height,$MyData);

 /* Draw the background */
 $Settings = array("R"=>170, "G"=>183, "B"=>87, "Dash"=>1, "DashR"=>190, "DashG"=>203, "DashB"=>107);
// $myPicture->drawFilledRectangle(0,0,$width,$height,$Settings);

 /* Overlay with a gradient */
$Settings = array("StartR"=>219, "StartG"=>231, "StartB"=>139, "EndR"=>1, "EndG"=>138, "EndB"=>68, "Alpha"=>50);
//$myPicture->drawGradientArea(0,0,$width,$height,DIRECTION_VERTICAL,$Settings);
$myPicture->drawGradientArea(0,0,$width,40,DIRECTION_VERTICAL,array("StartR"=>100,"StartG"=>100,"StartB"=>255,"EndR"=>255,"EndG"=>255,"EndB"=>255,"Alpha"=>100));

 /* Add a border to the picture */
 $myPicture->drawRectangle(0,0,$width-1,$height-1,array("R"=>0,"G"=>0,"B"=>0));

 /* Write the picture title */
 $myPicture->setFontProperties(array("FontName"=>"pChart/fonts/pf_arma_five.ttf","FontSize"=>12));
// $myPicture->drawText(10,13,"drawPlotChart() - draw a plot chart",array("R"=>255,"G"=>255,"B"=>255));
 $myPicture->drawText(10,15,$plotTitle,array("R"=>0,"G"=>0,"B"=>0));
 $myPicture->drawText(10,30,$plotTitle2,array("R"=>0,"G"=>0,"B"=>0));

 /* Write the chart title */
// $myPicture->setFontProperties(array("FontName"=>"pChart/fonts/Forgotte.ttf","FontSize"=>11));
// $myPicture->drawText(250,55,"Average temperature",array("FontSize"=>20,"Align"=>TEXT_ALIGN_BOTTOMMIDDLE));

 /* Draw the scale and the 1st chart */
 $myPicture->setGraphArea(60,60,$width-60,$height-200);

/* Create the Scatter chart object */
$myScatter = new pScatter($myPicture,$myData);

/* Draw the scale */
$AxisBoundaries = array(0=>array("Min"=>0,"Max"=>3600,"Rows"=>12,"RowHeight"=>300),1=>array("Min"=>0,"Max"=>100));
//$ScaleSettings = array("Mode"=>SCALE_MODE_MANUAL,"ManualScale"=>$AxisBoundaries,"DrawSubTicks"=>TRUE);
$ScaleSettings = array("Mode"=>SCALE_MODE_FLOATING,"DrawSubTicks"=>TRUE,"LabelRotation"=>45,"GridR"=>100,"GridG"=>100,"GridB"=>100,"LineWeight"=>5);
$myScatter->drawScatterScale($ScaleSettings);

//$myScatter->drawScatterScale();

/* Turn on shadow computing */
//$myPicture->setShadow(TRUE,array("X"=>1,"Y"=>1,"R"=>0,"G"=>0,"B"=>0,"Alpha"=>10));

/* Draw a scatter plot chart */
$myScatter->drawScatterPlotChart();
$myScatter->drawScatterLineChart(array("Weight"=>5));

/* Draw the legend */
//$myScatter->drawScatterLegend(260,375,array("Mode"=>LEGEND_HORIZONTAL,"Style"=>LEGEND_NOBORDER));
$myScatter->drawScatterLegend(50,$height-25,array("Mode"=>LEGEND_HORIZONTAL,"Style"=>LEGEND_NOBORDER));
//$myPicture->drawLegend(50,$height-25,array("Style"=>LEGEND,"Mode"=>LEGEND_HORIZONTAL));

/* Render the picture (choose the best way) */
$myPicture->autoOutput("pictures/example.drawScatterPlotChart.png");





// $myPicture->drawFilledRectangle(60,60,$width-60,$height-100,array("R"=>255,"G"=>255,"B"=>255,"Surrounding"=>-200,"Alpha"=>10));
// $myPicture->drawScale(array("DrawSubTicks"=>TRUE, "LabelSkip"=>9,"LabelRotation"=>30,"GridR"=>0,"GridG"=>0,"GridB"=>0));
// $myPicture->setShadow(TRUE,array("X"=>1,"Y"=>1,"R"=>0,"G"=>0,"B"=>0,"Alpha"=>10));
// $myPicture->setFontProperties(array("FontName"=>"pChart/fonts/pf_arma_five.ttf","FontSize"=>12));
// $myPicture->drawLineChart(array("BorderSize"=>1,"Surrounding"=>40,"BorderAlpha"=>100,"PlotSize"=>2,"PlotBorder"=>TRUE,"DisplayValues"=>FALSE,"DisplayColor"=>DISPLAY_AUTO,"DrawSubTicks"=>TRUE));
// $myPicture->setShadow(FALSE);








?>
