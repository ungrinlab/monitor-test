<?php
if ($_POST["from_config_form"] != "yes") {
	include '/var/www/configure.php';
	exit;
}
include '/var/www/header.php';

$config_file = "sensor_config.php";

echo "<BODY>";
	for ($i=0; $i < 8; $i++) {
                if ($_POST["m_port".$i."_low"] == "") $_POST["m_port".$i."_low"] = -99999;
                if ($_POST["m_port".$i."_high"] == "") $_POST["m_port".$i."_high"] = 99999;
		if ($_POST["m_port".$i."_type"] != "NONE") {
	                echo "The sensor on port M".$i." is a ".$_POST["m_port".$i."_type"]." sensor, ";
	                if ($_POST["m_port".$i."_name"] == "") $_POST["m_port".$i."_name"] = "Port M".$i;
			echo "labelled '".$_POST["m_port".$i."_name"]."'.";
			echo " Normal values are expected to range from ".$_POST["m_port".$i."_low"]." to ".$_POST["m_port".$i."_high"].".<BR>";

		} else {
	                echo "Port M".$i." is unused.<BR>";
		}
	}

	for ($i=0; $i < 8; $i++) {
                if ($_POST["d_port".$i."_state"] == "") $_POST["d_port".$i."_state"] = FALSE;
		if ($_POST["d_port".$i."_name"] != "") {
	                echo "The sensor on port D".$i." is a digital sensor, ";
			echo "labelled '".$_POST["d_port".$i."_name"]."'.";
			echo " Normal output value is expected to be ".$_POST["d_port".$i."_expected_state"].", ";
			echo " deviations are considered acceptable for up to ".$_POST["d_port".$i."_timeout"]." minutes.<BR>";
		} else {
	                echo "Port D".$i." is unused.<BR>";
		}
	}

	for ($i=0; $i < 4; $i++) {
                if ($_POST["t_port".$i."_low"] == "") $_POST["t_port".$i."_low"] = -99999;
                if ($_POST["t_port".$i."_high"] == "") $_POST["t_port".$i."_high"] = 99999;
		if ($_POST["t_port".$i."_name"] != "") {
	                echo "The sensor on port T".$i." is a thermocouple, ";
			echo "labelled '".$_POST["t_port".$i."_name"]."'.";
			echo " Normal values are expected to range from ".$_POST["t_port".$i."_low"]." to ".$_POST["t_port".$i."_high"].".<BR>";

		} else {
	                echo "Port T".$i." is unused.<BR>";
		}
	}

        if ($_POST["repeat_alert"] == "") {
		$email_timer="10";
	} else {
		$email_timer=$_POST["repeat_alert"];
	}

	$epwd = $_POST["email_password"];
        if (strlen($epwd) == 0) {
                $findname="cat $config_file | grep 'Password = ' | perl -pe 's/Password = //g'";
                exec($findname, $email_password);
		$epwd = $email_password[0];
		echo "<p>Email password not entered, keeping previous password</p>";
	}

	$prefs='
[General_settings]

EXIT = <?php exit; ?>

#Email Set-up
# The Emailing system accesses a GMAIL account to send emails to a specified email address.

Email Timer = '.$email_timer.'


';
	$prefs = $prefs."To Address = ".$_POST["to_address"]."\r\n";
	$prefs = $prefs."From Address = ".$_POST["from_address"]."\r\n";
	if (strlen($epwd) > 0) {
		$prefs = $prefs."Password = ".$epwd."\r\n";
		echo "Email password updated<BR>";
	} else {
		echo "EMAIL PASSWORD LEFT BLANK!<BR>";
	}
	$prefs = $prefs."InterfaceKit connected = ".$_POST["interfacekit_connected"]."\r\n";
	$prefs = $prefs."Thermocouple connected = ".$_POST["thermocouple_connected"]."\r\n";

	$prefs = $prefs."[InterfaceKit_settings]\r\n";

        for ($i=0; $i < 8; $i++) {

		$prefs=$prefs."#m_port".$i."_name = ".$_POST["m_port".$i."_name"]."\r\n";
		$prefs=$prefs."#m_port".$i."_type = ".$_POST["m_port".$i."_type"]."\r\n";
//		$prefs=$prefs."Port M".$i." = ".$_POST["m_port".$i."_name"]." (".$_POST["m_port".$i."_type"].")\r\n";
		if ($_POST["m_port".$i."_type"] == "NONE") {
			$prefs=$prefs."Port M".$i." = \r\n";
		} else {
			$prefs=$prefs."Port M".$i." = ".$_POST["m_port".$i."_name"]." (".$_POST["m_port".$i."_type"].")\r\n";
		}
		$prefs=$prefs."upper limit M".$i." = ".$_POST["m_port".$i."_high"]."\r\n";
		$prefs=$prefs."lower limit M".$i." = ".$_POST["m_port".$i."_low"]."\r\n";
		$prefs=$prefs."\r\n";
	}

        for ($i=0; $i < 8; $i++) {

		$prefs=$prefs."#d_port".$i."_name = ".$_POST["d_port".$i."_name"]."\r\n";
		$prefs=$prefs."Port D".$i." = ".$_POST["d_port".$i."_name"]."\r\n";
		$prefs=$prefs."desired state D".$i." = ".$_POST["d_port".$i."_expected_state"]."\r\n";
		$prefs=$prefs."state timeout D".$i." = ".$_POST["d_port".$i."_timeout"]."\r\n";
		$prefs=$prefs."\r\n";
	}

	$prefs = $prefs."[Thermocouple_settings]\r\n";

        for ($i=0; $i < 4; $i++) {

		$prefs=$prefs."#t_port".$i."_name = ".$_POST["t_port".$i."_name"]."\r\n";
		$prefs=$prefs."Port T".$i." = ".$_POST["t_port".$i."_name"]."\r\n";
		$prefs=$prefs."upper limit T".$i." = ".$_POST["t_port".$i."_high"]."\r\n";
		$prefs=$prefs."lower limit T".$i." = ".$_POST["t_port".$i."_low"]."\r\n";
		$prefs=$prefs."\r\n";
	}

	$config_result = file_put_contents($config_file,$prefs);


	$new_username=$_POST["username"];
	$new_password=$_POST["password"];

	if (($new_username == "") || (($new_username == $username) && ($new_password == $password))){
		echo "Login / password  for sensor configuration not updated.";
	} else {
        	$content='<?php
        	$username = "'.$new_username.'";
        	$password = "'.$new_password.'";
        	?>';

	        file_put_contents("/var/www/pwd.php",$content);

	        echo "<p>Login credentials updated</p>";
        	echo "<p>New login: $new_username</p>";
        	echo "<p>New password: $new_password</p>";
	}


	echo "<BR>Configuration file ($config_file) has been updated ($config_result). Alert emails will be sent from ".$_POST["from_address"]." to ".$_POST["to_address"].", with delay set to $email_timer minutes between emails.<BR><a href='index.php'>Click here to return to main screen.</a><BR>";
        echo "</BODY>";
?>

