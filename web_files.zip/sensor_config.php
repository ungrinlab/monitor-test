
[General_settings]

EXIT = <?php exit; ?>

#Email Set-up
# The Emailing system accesses a GMAIL account to send emails to a specified email address.

Email Timer = 10


To Address = MY_EMAIL@ANY.WHERE
From Address = MY_NEW_EMAIL_ADDRESS@gmail.com
Password = 
InterfaceKit connected = Y
Thermocouple connected = N
[InterfaceKit_settings]
#m_port0_name = 
#m_port0_type = NONE
Port M0 = 
upper limit M0 = 50
lower limit M0 = 30

#m_port1_name = 
#m_port1_type = NONE
Port M1 = 
upper limit M1 = 25
lower limit M1 = 10

#m_port2_name = absolute pressure
#m_port2_type = pressure [1140]
Port M2 = absolute pressure (pressure [1140])
upper limit M2 = 100
lower limit M2 = 0

#m_port3_name = ambient temperature
#m_port3_type = temperature [1124]
Port M3 = ambient temperature (temperature [1124])
upper limit M3 = 25
lower limit M3 = 10

#m_port4_name = 
#m_port4_type = NONE
Port M4 = 
upper limit M4 = 54
lower limit M4 = 18

#m_port5_name = 
#m_port5_type = NONE
Port M5 = 
upper limit M5 = 0
lower limit M5 = 100

#m_port6_name = 
#m_port6_type = NONE
Port M6 = 
upper limit M6 = 0
lower limit M6 = 100

#m_port7_name = 
#m_port7_type = NONE
Port M7 = 
upper limit M7 = 0
lower limit M7 = 100

#d_port0_name = magnetic sensor
Port D0 = magnetic sensor
desired state D0 = FALSE
state timeout D0 = 720

#d_port1_name = 
Port D1 = 
desired state D1 = FALSE
state timeout D1 = 

#d_port2_name = 
Port D2 = 
desired state D2 = FALSE
state timeout D2 = 

#d_port3_name = 
Port D3 = 
desired state D3 = FALSE
state timeout D3 = 

#d_port4_name = 
Port D4 = 
desired state D4 = FALSE
state timeout D4 = 

#d_port5_name = 
Port D5 = 
desired state D5 = FALSE
state timeout D5 = 

#d_port6_name = 
Port D6 = 
desired state D6 = FALSE
state timeout D6 = 

#d_port7_name = 
Port D7 = 
desired state D7 = FALSE
state timeout D7 = 

[Thermocouple_settings]
#t_port0_name = 
Port T0 = 
upper limit T0 = 10
lower limit T0 = 10

#t_port1_name = 
Port T1 = 
upper limit T1 = 10
lower limit T1 = 10

#t_port2_name = 
Port T2 = 
upper limit T2 = 10
lower limit T2 = 10

#t_port3_name = 
Port T3 = 
upper limit T3 = 10
lower limit T3 = 10

