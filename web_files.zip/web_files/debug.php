<?php
echo "<pre>";
include "logs/most_recent_scan.log";
echo "</pre>";
echo "<a href='index.php'>Return to main page</a>";
?>

