<script>
	function makeImageURL() {
		var w = document.getElementById("width").value;
		var h = document.getElementById("height").value;
		var skip = document.getElementById("skip").value;
		var numX = document.getElementById("numX").value;
		var seriesOpts = document.getElementById("series").options;
		var series = "";
		for (var i=0; i < seriesOpts.length; i++) {
			if (seriesOpts[i].selected) {
				if (series.length > 0 ) series=series+",";
				series=series+seriesOpts[i].value;
			}
		}
		document.getElementById("plot").src = "plotData.php?width="+w+"&height="+h+"&numX="+numX+"&skip="+skip+"&series="+series;
	}
	window.onload = makeImageURL;
</script>
<?php

$plotTitle=$_GET["plotTitle"];
$height=$_GET["height"];
$width=$_GET["width"];
$skipData = $_GET["skip"];
$numDataPoints = $_GET["numX"];
$showSeries = explode(",",$_GET["series"]);
if ($height < 200) $height=800;
if ($width < 300) $width=1000;
if ($skipData < 1) $skipData=1;
if ($numDataPoints < 1) $numDataPoints=100;
if ($showSeries == NULL) $showSeries = "ALL";



$tmp='cat monitor_log.txt | perl -pe "s/(^.*?\@)|(=.*?\@)|(=.*?$)/\n/g" | sort | uniq | grep "."';
$tmp='cat monitor_log.txt | perl -pe "s/(^.*?\|)|(=.*?\|)|(=.*?$)/\n/g" | sort | uniq | grep "." | perl -pe "s/(.*)\@(.*)/\2@\1/g" | sort';

exec($tmp,$allSensors);
$uniqPorts=array();
foreach ($allSensors as $thisSensor) {
	$thisPort=strstr($thisSensor,"@",TRUE);
	$thisName=substr(strstr($thisSensor,"@"),1);
	if (array_key_exists($thisPort,$uniqPorts)) {
		$uniqPorts[$thisPort] = $uniqPorts[$thisPort].' AND ALSO "'.$thisName.'"';
	} else {
		$uniqPorts[$thisPort] = '"'.$thisName.'"';
	}
}

echo '<BR><img id="plot" src="" alt="LOADING PLOT..."><BR>';

echo "Available sensors with at least one datapoint:<BR>";
echo "<select id='series' multiple size=".count($uniqPorts).">";



foreach ($uniqPorts as $thisPort => $thisName) {
	if (in_array("ALL",$showSeries) | in_array($thisPort,$showSeries)) {
		$isSel=" SELECTED";
	} else {
		$isSel="";
	}

	echo "<option value='$thisPort'$isSel>$thisPort:$thisName</option>\n";
}
echo "</select><BR>";
echo "Width:<input id='width' type='number' value='$width' size=4><BR>";
echo "Height:<input id='height' type='number' value='$height' size=4><BR>";
echo "Read every Nth datapoint:<input id='skip' type='number' value='$skipData' size=4><BR>";
echo "Show N datapoints:<input id='numX' type='number' value='$numDataPoints' size=4><BR>";
?>

<input type='button' value='Redraw plot (may take a few seconds to load)' onClick='makeImageURL()'>
<br><a href='index.php'>Click here to return to main screen.</a><br>

