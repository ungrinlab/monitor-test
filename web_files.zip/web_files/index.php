<html>
<head>
	<meta http-equiv="refresh" content="30">
	<title>Ungrin lab remote monitoring system 2</title>
	<style>
	hr {color:sienna;}
	p {margin: 0px}
	body {background-image:url("images/background.gif");}
	p.goodValue {
		font:bold 48px Arial;
		color:#008800;
		text-align:center;
	}
	p.badValue {
		font:bold 48px Arial;
		color:#DD0000;
		text-align:center;
	}
	p.sensorLabels {
		font:bold 16px Arial;
	}
	p.indicator {
		font-family: "Courier", "Futura", "Arial";
		font-size: 72px;
		font-style: bold;
	}
	p.label {
		font:bold 12px Arial;
	}
	div.sensorBlock {
		float:left;
		border:2px solid;
		border-radius:25px;
		box-shadow: 10px 10px 5px #BBBBBB;
		padding:5px;
		margin:15px;
		width:150px;
		height:240px;
	}
	div.goodValue {
		background-color:#AAFFAA;
		text-align:center;
	}
	div.noSensor {
		background-color:#FFFFAA;
		text-align:center;
	}
	div.badValue {
		background-color:#FFAAAA;
		text-align:center;
	}
	div.indicator {
		float:left;
		border:5px solid;
		border-radius:25px;
		border-color:#00BB00;
		background-color: #000000;
		box-shadow: 10px 10px 5px #BBBBBB;
		padding:5px;
		margin:15px;
		vertical-align: middle;
		color:#00EE00;
		text-align:center;
		height:118px;
	}
	div.bad_indicator {
		float:left;
		border:5px solid;
		border-radius:25px;
		border-color:#000000;
		background-color: #DD0000;
		box-shadow: 10px 10px 5px #BBBBBB;
		padding:5px;
		margin:15px;
		vertical-align: middle;
		color:#000000;
		text-align:center;
		height:118px;
	}
	div.headerIcon {
		float:left;
		padding:5px;
		margin:15px;
		width:128px;
		height:128px;
	}
	div.rowDiv {
		width:100%;
		overflow:hidden;
	}
	a:link {text-decoration:none;color:#000000;}    /* unvisited link */
	a:visited {text-decoration:none;} /* visited link */
	a:hover {text-decoration:none;color:#FF0000;}   /* mouse over link */
	a:active {text-decoration:none;}  /* selected link */

	</style>
</head>
<body>
<?php

$configfile = "/var/www/sensor_config.php";
exec('cat monitor_log.txt | tail -n 1',$output);


// echo "<P>Starting with $output[0]</P>";
$values=explode("|",$output[0]);
$num_sensors=count($values)-1;

echo "<DIV class='rowDiv'>";
for ($i = 1; $i <= $num_sensors; $i++) {

	$matches=NULL;
	$portField = $values[$i];
//        preg_match('@on port (.*?) is@i',$portField, $matches);
        preg_match('@(.*?)\@(.*?)=(.*)@i',$portField, $matches);
	$portName = $matches[1];
	$portNum = $matches[2];
	$portType = substr($portNum,0,1);

	echo "<a href='plotControl.php?width=1200&height=600&numX=100&series=".$portNum."&skip=60'>";

	switch ($portType) {
		case "M":
			$portVal = round(strtok(trim($matches[3])," "),1);
			$command = 'cat '.$configfile.' | grep "upper limit '.$portNum.'"';
			$result=NULL;
			exec($command,$result);
		        preg_match("@upper limit $portNum = (.*)@i",$result[0], $thenumber);
			$upperLim = $thenumber[1];

			$command = 'cat '.$configfile.' | grep "lower limit '.$portNum.'"';
			$result=NULL;
			$result=NULL;
			exec($command,$result);
		        preg_match("@lower limit $portNum = (.*)@i",$result[0], $thenumber);
			$lowerLim = $thenumber[1];

			if (($portVal>=$lowerLim) && $portVal <= $upperLim)  {
				echo "<DIV class='sensorBlock goodValue'>";
			} else {
				echo "<DIV class='sensorBlock badValue'>";
			}
			echo "<P class='sensorLabels'>Port $portNum</P>";
			if (($portVal>=$lowerLim) && $portVal <= $upperLim)  {
				echo "<p class='goodValue'>";
			} else {
				echo "<p class='badValue'>";
			}
			echo "$portVal</p>";

        		echo "<P class='sensorLabels'><img src='AX11-graph.png' width=48px title='Plot this sensor'></P>";
			echo "<P class='sensorLabels'>$portName</P>";
        		echo "<P class='sensorLabels'>(".$lowerLim." to ".$upperLim.")<P>";
			echo "</DIV>";

		break;

		case "D":
			$portVal = filter_var(trim($matches[3]), FILTER_VALIDATE_BOOLEAN);
			if ($portVal) {
				$portValText = "closed";
			} else {
				$portValText = "open";
			}
			$command = 'cat '.$configfile.' | grep "desired state '.$portNum.'"';
			$result=NULL;
			exec($command,$result);
		        preg_match("@desired state $portNum = (.*)@i",$result[0], $thenumber);
			$desiredState = filter_var($thenumber[1], FILTER_VALIDATE_BOOLEAN);
			if ($desiredState) {
				$desiredStateText = "closed";
			} else {
				$desiredStateText = "open";
			}

			$command = 'cat '.$configfile.' | grep "state timeout '.$portNum.'"';
			$result=NULL;
			$result=NULL;
			exec($command,$result);
		        preg_match("@state timeout $portNum = (.*)@i",$result[0], $thenumber);
			$stateTimeout = $thenumber[1];

			if ($portVal==$desiredState)  {
				echo "<DIV class='sensorBlock goodValue'>";
			} else {
				echo "<DIV class='sensorBlock badValue'>";
			}
			echo "<P class='sensorLabels'>Port $portNum</P>";
			if ($portVal==$desiredState)  {
				echo "<p class='goodValue'>";
			} else {
				echo "<p class='badValue'>";
			}
			echo "$portValText</p>";

        		echo "<P class='sensorLabels'><img src='AX11-graph.png' width=48px title='Plot this sensor'></P>";
			echo "<P class='sensorLabels'>$portName</P>";
        		echo "<P class='sensorLabels'>(should be $desiredStateText)</P>";
			echo "</DIV>";

		break;

		case "T":
			$portVal = round(strtok(trim($matches[3])," "),1);
			$command = 'cat '.$configfile.' | grep "upper limit '.$portNum.'"';
			$result=NULL;
			exec($command,$result);
		        preg_match("@upper limit $portNum = (.*)@i",$result[0], $thenumber);
			$upperLim = $thenumber[1];

			$command = 'cat '.$configfile.' | grep "lower limit '.$portNum.'"';
			$result=NULL;
			$result=NULL;
			exec($command,$result);
		        preg_match("@lower limit $portNum = (.*)@i",$result[0], $thenumber);
			$lowerLim = $thenumber[1];

			if (trim($matches[3]) == "NOT_FOUND") {
				echo "<DIV class='sensorBlock noSensor'";
				$portVal = "NOT_FOUND";
			} else if (($portVal>=$lowerLim) && $portVal <= $upperLim)  {
				echo "<DIV class='sensorBlock goodValue'>";
			} else {
				echo "<DIV class='sensorBlock badValue'>";
			}
			echo "<P class='sensorLabels'>Port $portNum</P>";
			if (($portVal>=$lowerLim) && $portVal <= $upperLim)  {
				echo "<p class='goodValue'>";
			} else {
				echo "<p class='badValue'>";
			}
			echo "$portVal</p>";

        		echo "<P class='sensorLabels'><img src='AX11-graph.png' width=48px title='Plot this sensor'></P>";
			echo "<P class='sensorLabels'>$portName</P>";
        		echo "<P class='sensorLabels'>(".$lowerLim." to ".$upperLim.")<P>";
			echo "</DIV>";

		break;

	}



	echo "</a>\r\n";
}
echo "</DIV>";

exec('date',$dateNow);

$dateTime=substr($values[0],strpos($values[0]," ")+1);
$elapsed_time = (time()-strtotime($dateTime));
echo "<DIV class='rowDiv'>";
if ($elapsed_time > 60) {
	echo "<a href='debug.php'><DIV class='bad_indicator' title='Time since last scan'>";
} else {
	echo "<a href='debug.php'><DIV class='indicator' title='Time since last scan'>";
}
echo "<P class='indicator'>".date('G:i:s',$elapsed_time)."</p>";
echo "<P class='label'>$dateNow[0]</p>";
echo "</div></a>";
echo "\r\n";

echo "<DIV class='headerIcon'><a href='plotControl.php?width=1200&height=600&numX=100&series=ALL&skip=60'><img src='AX11-graph.png' width=100% title='Plot all sensors'></a></DIV>";
echo "<DIV class='headerIcon'><a href='update_sensor_config.php'><img src='Andy-Tools-Hammer-Spanner.png' width=100% title='Configure sensors'></a></DIV>";
echo "<DIV class='headerIcon'><a href='monitor_log.txt'><img src='Download-box.png' width=100% title='Download raw sensor data'></a></DIV>";
echo "<DIV class='headerIcon'><a href='alert_log.txt'><img src='zeimusu-Warning-notification.png' width=100% title='Download alert log'></a></DIV>";
echo "<DIV class='headerIcon'><a href='debug.php'><img src='ryanlerch-Yellow-Query-Icon.png' width=100% title='Check most recent scan log'></a></DIV>";
echo "<DIV class='headerIcon'><a href='copyright.php'><img src='copyright.png' width=100% title='Show copyright information'></a></DIV>";
echo "</DIV>";
//echo "<DIV class='indicator' title='Seconds since last scan'>".(time()-strtotime($dateTime))."s</DIV>";
?>
</body>
</html>
