<h1><img src="gplv3-127x51.png"></h1>
<p>&copy;2015, Akshay Gurdita and Mark Ungrin (<a href="http://ucalgary.ca/ungrinlab">http://ucalgary.ca/ungrinlab</a>).  This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the <a href="gpl-3.0-standalone.html">GNU General Public License</a> for more details.

<p>This code is built upon code provided by <a href="http://www.phidgets.com">Phidgets</a> under the Gnu Lesser General Public License (<a href="lgpl-3.0-standalone.html">LGPL V3.0</a>) and the <a href="http://www.pchart.net">pChart</a> PHP charting libraries, under the Gnu General Public License (<a href="gpl-3.0-standalone.html">GPL V3.0</a>). 
Public-domain icons from the <a href="https://openclipart.org">openclipart repository</a> have also been used in several places.</p>

<p><a href="index.php">Return to main page</a>.


