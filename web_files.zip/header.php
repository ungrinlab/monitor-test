<?php
header("Content-type: text/html; charset=utf-8");
include '/var/www/pwd.php';
if((empty($_SERVER['PHP_AUTH_USER'])) || (($_SERVER['PHP_AUTH_USER'] != $username) || ($_SERVER['PHP_AUTH_PW'] != $password))) {
    header('WWW-Authenticate: Basic realm="Please log in to continue"');
    header('HTTP/1.0 401 Unauthorized');
    echo "You must log in to access this page.";
    exit;
}
?>
