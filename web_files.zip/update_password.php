<?php
include '/var/www/header.php';


$new_username=$_POST["username"];
$new_password=$_POST["password"];

if ($new_username == "") {
	echo "New username must not be blank";
?>
<form action='update_password.php' method='post'>
	<p>New login: <input type='text' value='<?php echo $username; ?>' size=50 name='username'></p>
	<p>New password: <input type='text' size=50 name='password'></p>
	<p><input type='submit'></P>
</form>
<?php
} else {
	$content='<?php
	$username = "'.$new_username.'";
	$password = "'.$new_password.'";
	?>';



	file_put_contents("/var/www/pwd.php",$content);

	echo "<p>Login credentials updated</p>";
	echo "<p>New login: $new_username</p>";
	echo "<p>New password: $new_password</p>";

}
?>
<a href="index.php">Click here to return to main screen</a>
